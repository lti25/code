# Md soln (All Case Passed)

34.2.2 **Create an Angular application with a reactive form**

# app.component.ts

```tsx

import { Component } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
 
 
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {
  itemForm: any;
  submitted: boolean =false;
  constructor(fb : FormBuilder){
    this.itemForm = fb.group({
      Username:['',[Validators.required, Validators.minLength(6)]],
      Password:['', [Validators.required,Validators.minLength(8), Validators.pattern("^[0-9A-Za-z]*$")]]
    })
  }
  onRegister(){
    if(this.itemForm.valid){
      this.submitted=true;
    }else{
      this.itemForm.markAllAsTouched;
    }
  }
}
```

# app.component.html

```tsx
<h2>ANGULAR REACTIVE FORM</h2>
<p>Please enter your details here</p>
<form [formGroup]="itemForm" (submit)="onRegister()">
<div class="form-group">
	<label for="Username">Username</label>
	<input type="text" name="Username" class="form-control" placeholder="Patient Name" formControlName ="Username" required>
	<div *ngIf="itemForm.get('Username')?.invalid && itemForm.get('Username')?.touched">
		<div *ngIf="itemForm.get('Username')?.errors?.required">Username is required.</div>
		<div *ngIf="itemForm.get('Username')?.errors?.minLength">Username less than 6 words</div>
	</div>
	
	<label for="Password">Password</label>
	<input type="text" name="Password" class="form-control" placeholder="Password" formControlName ="Password" required>
	<div *ngIf="itemForm.get('Password')?.invalid && itemForm.get('Password')?.touched">
		<div *ngIf="itemForm.get('Password')?.errors?.required">Password .</div>
		<div *ngIf="itemForm.get('Password')?.errors?.minLength">Password minimum length greater then 8 words</div>
	 </div>
	<button type="submit"></button>
</div>
</form>
```