# 34.3.2 ⭐⭐⭐ …. (cw) Develop an Angular application for managing an online bookstore

Status: Not started

**D34_S3_A2_Develop an Angular application for managing an online bookstore**