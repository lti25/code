# 32.2.2 (submitted) [Md] Task Management implement Conditional Rendering and Styling Based Task

Status: Not started

[task-detail.component.html.txt](32%202%202%20(submitted)%20%5BMd%5D%20Task%20Management%20implement%20%20184299dbb04a808a929ad67e8eebe80d/task-detail.component.html.txt)

[task-list.component.ts.txt](32%202%202%20(submitted)%20%5BMd%5D%20Task%20Management%20implement%20%20184299dbb04a808a929ad67e8eebe80d/task-list.component.ts.txt)

[task-list.component.html.txt](32%202%202%20(submitted)%20%5BMd%5D%20Task%20Management%20implement%20%20184299dbb04a808a929ad67e8eebe80d/task-list.component.html.txt)

[app.component.html.txt](32%202%202%20(submitted)%20%5BMd%5D%20Task%20Management%20implement%20%20184299dbb04a808a929ad67e8eebe80d/app.component.html.txt)

[app-routing.module.ts.txt](32%202%202%20(submitted)%20%5BMd%5D%20Task%20Management%20implement%20%20184299dbb04a808a929ad67e8eebe80d/app-routing.module.ts.txt)