# 34.2.2 ✅[cw] [reactive form] Create an Angular application with a reactive form

Status: Not started

[Md soln (All Case Passed)](34%202%202%20%E2%9C%85%5Bcw%5D%20%5Breactive%20form%5D%20Create%20an%20Angular%20app%20184299dbb04a80f3b1dde447c80d1a9f/Md%20soln%20(All%20Case%20Passed)%20184299dbb04a8098be05c40e4292bb24.md)