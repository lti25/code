# 34.3.2 ……….. Develop an Angular application for managing an online bookstore

Status: Not started

abdullah partial test case passed