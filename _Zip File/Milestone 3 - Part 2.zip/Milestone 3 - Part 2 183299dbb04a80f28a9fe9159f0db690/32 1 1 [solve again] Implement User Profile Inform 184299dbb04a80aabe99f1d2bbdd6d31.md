# 32.1.1  [solve again] Implement User Profile Information system using @Input and @Output in Angular

Status: Not started

[app.component.html 2.txt](32%201%201%20%5Bsolve%20again%5D%20Implement%20User%20Profile%20Inform%20184299dbb04a80aabe99f1d2bbdd6d31/app.component.html_2.txt)

[app-routing.modules.ts.txt](32%201%201%20%5Bsolve%20again%5D%20Implement%20User%20Profile%20Inform%20184299dbb04a80aabe99f1d2bbdd6d31/app-routing.modules.ts.txt)

[child.component.html.txt](32%201%201%20%5Bsolve%20again%5D%20Implement%20User%20Profile%20Inform%20184299dbb04a80aabe99f1d2bbdd6d31/child.component.html.txt)

[child.component.ts.txt](32%201%201%20%5Bsolve%20again%5D%20Implement%20User%20Profile%20Inform%20184299dbb04a80aabe99f1d2bbdd6d31/child.component.ts.txt)

[parent.component.html.txt](32%201%201%20%5Bsolve%20again%5D%20Implement%20User%20Profile%20Inform%20184299dbb04a80aabe99f1d2bbdd6d31/parent.component.html.txt)

[parent.component.ts.txt](32%201%201%20%5Bsolve%20again%5D%20Implement%20User%20Profile%20Inform%20184299dbb04a80aabe99f1d2bbdd6d31/parent.component.ts.txt)