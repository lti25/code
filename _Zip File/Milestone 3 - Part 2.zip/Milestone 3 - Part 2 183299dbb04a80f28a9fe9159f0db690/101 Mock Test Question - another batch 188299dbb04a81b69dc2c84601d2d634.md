# 101. Mock Test Question - another batch

Status: Not started

[nse-8933801681494419277-0bab3c67-6863-4a22-a1e6-07e9b1106b7d.pdf](101%20Mock%20Test%20Question%20-%20another%20batch%20188299dbb04a81b69dc2c84601d2d634/nse-8933801681494419277-0bab3c67-6863-4a22-a1e6-07e9b1106b7d.pdf)