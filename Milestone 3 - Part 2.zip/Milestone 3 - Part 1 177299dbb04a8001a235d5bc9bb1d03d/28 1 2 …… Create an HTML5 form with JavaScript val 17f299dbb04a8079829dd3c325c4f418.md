# 28.1.2 …… Create an HTML5 form with JavaScript validation for an event registration system

**D28_S1_A2_Create an HTML5 form with JavaScript validation for an event registration system**