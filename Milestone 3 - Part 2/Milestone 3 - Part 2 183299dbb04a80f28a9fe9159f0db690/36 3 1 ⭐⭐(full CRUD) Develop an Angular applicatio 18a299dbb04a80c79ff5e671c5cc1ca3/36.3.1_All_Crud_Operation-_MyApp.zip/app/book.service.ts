import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Book } from './Models/book.model';
import { environment } from 'src/environments/environment.development';


@Injectable({
  providedIn: 'root'
})
export class BookService {
  private apiUrl = environment.apiUrl;
  
  constructor(private http: HttpClient) { }
  
  getBooks(): Observable<Book[]> {
    //todo: complete missing code..
    console.log(this.apiUrl);
    return this.http.get<Book[]>(`${this.apiUrl}`);
  }

  getBook(id: any): Observable<Book> {
    //todo: complete missing code..

    return this.http.get<Book>(`${this.apiUrl}/${id}`);
    
  }
  
  addBook(book: Book): Observable<Book> {
    //todo: complete missing code..
    return this.http.post<Book>(`${this.apiUrl}`, book);     
  }

  updateBook(id: number, book: Book): Observable<Book> {
    //todo: complete missing code..
    return this.http.put<Book>(`${this.apiUrl}/${id}`, book);
  }

  deleteBook(id: any): Observable<void> {
     //todo: complete missing code..
     return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }
}
