import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BookService } from '../book.service';
import { Book } from '../Models/book.model';

@Component({
  selector: 'app-book-form',
  templateUrl: './book-form.component.html',
  styleUrls: ['./book-form.component.css']
})
export class BookFormComponent implements OnInit {
  //todo: complete missing code..
  bookForm: FormGroup;

  constructor(private fb: FormBuilder, private bookService: BookService, private router: Router) {
    this.bookForm = this.fb.group({
      title: ['', Validators.required],
      author: ['', Validators.required],
      genre: ['', Validators.required],
      price: ['', [Validators.required, Validators.min(0)]],
      pages: ['', [Validators.required, Validators.min(0)]],
    });
  }

  ngOnInit(): void {        
  }

  onSubmit(): void {
    if (this.bookForm.valid) {
      console.log("form submit");
      const newBook: Book = this.bookForm.value;
      
      this.bookService.addBook(newBook).subscribe(()=> {
        this.router.navigate(['/']);
      });
      
      this.bookForm.reset();

    }
  }

  // action btn methods 
  onCancel(): void {
    this.router.navigate(['/']);
  }

}
