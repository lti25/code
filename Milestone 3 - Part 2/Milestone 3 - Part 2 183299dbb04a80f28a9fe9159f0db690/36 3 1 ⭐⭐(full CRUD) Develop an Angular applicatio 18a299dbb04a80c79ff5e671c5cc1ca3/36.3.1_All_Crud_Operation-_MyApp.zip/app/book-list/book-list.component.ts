import { Component, OnInit } from '@angular/core';
import { BookService } from '../book.service';
import { Book } from '../Models/book.model';


@Component({
  selector: 'app-book-list',
  templateUrl: './book-list.component.html',
  styleUrls: ['./book-list.component.css']
})
export class BookListComponent implements OnInit {
 //todo: complete missing code..

 books: Book[] = [];

 constructor(private bookService: BookService){}

  ngOnInit(): void {
    this.reloadBookList();
  }

reloadBookList(): void {  
  this.bookService.getBooks().subscribe(data => {
    this.books = data;
    console.log(data);
  } );
 }

   // --- ACTION BUTTONS - METHODS 
   viewBook(id: any): void {

   }
 
   deleteBook(id: any): void {
     this.bookService.deleteBook(id).subscribe( () => {
        this.reloadBookList();
     } )
   }

}
