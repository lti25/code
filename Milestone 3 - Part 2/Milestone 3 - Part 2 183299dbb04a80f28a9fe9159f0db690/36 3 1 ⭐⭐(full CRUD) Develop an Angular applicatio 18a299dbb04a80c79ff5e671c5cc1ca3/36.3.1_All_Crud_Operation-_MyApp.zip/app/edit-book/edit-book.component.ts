import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { BookService } from '../book.service';

@Component({
  selector: 'app-edit-book',
  templateUrl: './edit-book.component.html',
  styleUrls: ['./edit-book.component.css']
})
export class EditBookComponent implements OnInit {
  bookForm: FormGroup;
  currentBookId: any | null = null;

  constructor(
    private fb: FormBuilder,
    private bookService: BookService,
    private route: ActivatedRoute,
    private router: Router
  ) {
    this.bookForm = this.fb.group({
      title: ['', Validators.required],
      author: ['', Validators.required],
      genre: ['', Validators.required],
      price: [0, [Validators.required, Validators.min(0)]],
      pages: [0, [Validators.required, Validators.min(0)]],
    });
  }

  ngOnInit(): void {
    this.currentBookId = this.route.snapshot.paramMap.get('id')!;

    this.bookService.getBook(this.currentBookId).subscribe(data=> {
      this.bookForm.patchValue(data);
    })

  }

  // IT MEANS ON UPDATE BTN CLICK
  onSubmit(): void {
    this.bookService.updateBook(this.currentBookId, this.bookForm.value).subscribe( () => {
      this.router.navigate(['/']);
    } )
  }

}
