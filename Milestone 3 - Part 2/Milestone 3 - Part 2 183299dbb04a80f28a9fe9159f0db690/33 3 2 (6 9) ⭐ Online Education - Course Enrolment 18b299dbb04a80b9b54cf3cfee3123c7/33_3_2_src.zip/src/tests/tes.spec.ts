import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HomeComponent } from '../app/pages/home/home.component';
import { RouterTestingModule } from '@angular/router/testing';
import { Router } from '@angular/router';
import { DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';
describe('OnlineEducation', () => {
  let component: HomeComponent;
  let fixture: ComponentFixture<HomeComponent>;
  let router: Router;
  let debugElement: DebugElement;

  

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HomeComponent],
      imports: [ReactiveFormsModule, FormsModule,RouterTestingModule],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeComponent);
    component = fixture.componentInstance;
    router = TestBed.inject(Router);
    fixture.detectChanges();
    debugElement = fixture.debugElement;
  });

  it('should create the component', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize the form with the correct controls', () => {
    expect(component.itemForm).toBeDefined();
    expect(component.itemForm.get('StudentName')).toBeDefined();
    expect(component.itemForm.get('CourseName')).toBeDefined();
    expect(component.itemForm.get('PreferredSchedule')).toBeDefined();
    expect(component.itemForm.get('PreviousKnowledge')).toBeDefined();
  });

  it('should submit the form with valid inputs', waitForAsync(() => {
    // Spy on the onRegister method
    spyOn(component, 'onRegister');
  
    // Fill out the form with valid data
    component.itemForm.controls['StudentName'].setValue('John Doe');
    component.itemForm.controls['CourseName'].setValue('Computer Science');
    component.itemForm.controls['PreferredSchedule'].setValue('Morning');
    component.itemForm.controls['PreviousKnowledge'].setValue('ABC');
  
    fixture.detectChanges();
  
    // Check if the form is valid before submitting
    expect(component.itemForm.valid).toBeTruthy();
  
    // Simulate form submission
    const submitButton = fixture.debugElement.nativeElement.querySelector('button[type="submit"]');
    submitButton.click();
  
    // Perform assertions or make expectations based on the form submission
    expect(component.onRegister).toHaveBeenCalled();
  }));

  it('should submit the form with valid Course Name', waitForAsync(() => {
    // Spy on the onRegister method
    spyOn(component, 'onRegister');
  
    component.itemForm.controls['StudentName'].setValue('John Doe');
    component.itemForm.controls['PreferredSchedule'].setValue('Morning');
    component.itemForm.controls['PreviousKnowledge'].setValue('ABC');
    component.itemForm.controls['CourseName'].setValue('Computer ');
    fixture.detectChanges();
    expect(component.itemForm.valid).toBeTruthy();
    const submitButton = fixture.debugElement.nativeElement.querySelector('button[type="submit"]');
    submitButton.click();
    expect(component.itemForm.valid).toBeTruthy();
    // Perform assertions or make expectations based on the form submission
    expect(component.onRegister).toHaveBeenCalled();
  
    // Perform assertions or make expectations based on the form submission
    expect(component.onRegister).toHaveBeenCalled();
  }));

  it('should navigate to /welcome if form is valid', () => {
    // Set form values to make it valid
    component.itemForm.setValue({
      StudentName: 'John Doe',
      CourseName: 'Computer Science',
      PreferredSchedule: 'Morning',
      PreviousKnowledge: 'NO',
    });

    // Spy on router.navigateByUrl method
    const navigateByUrlSpy = spyOn(router, 'navigateByUrl');

    // Trigger the onRegister method
    component.onRegister();

    // Expect that router.navigateByUrl was called with '/welcome'
    expect(navigateByUrlSpy).toHaveBeenCalledWith('/welcome');
  });
  it('should navigate to /error if form is invalid', () => {
    // Set form values to make it invalid
    component.itemForm.setValue({
      StudentName: 'John Doe',
      CourseName: '',
      PreferredSchedule: 'Morning',
      PreviousKnowledge: 'NO',
    });

    // Spy on router.navigateByUrl method
    const navigateByUrlSpy = spyOn(router, 'navigateByUrl');

    // Trigger the onRegister method
    component.onRegister();

    // Expect that router.navigateByUrl was called with 'error'
    expect(navigateByUrlSpy).toHaveBeenCalledWith('error');
  });
  it('should display all the records in the Course dropdown', () => {
    fixture.detectChanges(); // Trigger change detection to update the view
  
    // Find the select element by its ID
    const selectElement = fixture.debugElement.query(By.css('#CourseName')).nativeElement;
  
    // Check the number of options in the dropdown
    const options = selectElement.querySelectorAll('option');
    expect(options.length).toBe(4); // Including the "Select" option and three other options
  
    // You can further check the text or values of the options if needed
    const optionTexts = Array.from(options).map((option: any) => option.textContent.trim());
    expect(optionTexts).toEqual(['Select', 'Computer Science', 'Commerce', 'Medical']);
  });
  it('should display all the records in the Scheduled dropdown', () => {
    fixture.detectChanges(); // Trigger change detection to update the view
  
    // Find the select element by its ID
    const selectElement = fixture.debugElement.query(By.css('#PreferredSchedule')).nativeElement;
  
    // Check the number of options in the dropdown
    const options = selectElement.querySelectorAll('option');
    expect(options.length).toBe(4); // Including the "Select" option and three other options
  
    // You can further check the text or values of the options if needed
    const optionTexts = Array.from(options).map((option: any) => option.textContent.trim());
    expect(optionTexts).toEqual(['Select', 'Morning', 'Afternoon', 'Evening']);
  });

  it('should display error messages for blank mandatory fields on form submission', () => {
    // Trigger change detection to update the view
    fixture.detectChanges();

    // Find the submit button and trigger a click event
    const submitButton = fixture.debugElement.query(By.css('button[type="submit"]')).nativeElement;
    submitButton.click();

    // Trigger change detection after clicking the submit button
    fixture.detectChanges();
    debugger;
    // Check for error messages related to blank mandatory fields
    const errorMessageElements = fixture.debugElement.queryAll(By.css('.text-danger'));

    // Ensure that there are error messages for all mandatory fields
    expect(errorMessageElements.length).toBe(4);

  });

  // Add more test cases as needed

  afterEach(() => {
    TestBed.resetTestingModule();
  });

});
class MockRouter {
  navigate = jasmine.createSpy('navigate');
}