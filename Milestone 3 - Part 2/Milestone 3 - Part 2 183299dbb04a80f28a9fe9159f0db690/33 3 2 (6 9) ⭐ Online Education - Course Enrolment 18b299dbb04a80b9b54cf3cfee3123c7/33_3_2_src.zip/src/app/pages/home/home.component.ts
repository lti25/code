import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent {
  //todo: complete missing code..
  
  itemForm: FormGroup;

  constructor(private fb: FormBuilder, private router: Router) {
    this.itemForm = this.fb.group({
      StudentName: ['', Validators.required],
      CourseName: ['', Validators.required],
      PreferredSchedule: ['', Validators.required],
      PreviousKnowledge: ['']
    });
  }

  ngOnInit(): void {
    // Additional initialization logic if needed
  }

  onRegister() {
    console.log(this.itemForm.value);
    if (this.itemForm.valid) {
      this.router.navigate(['/welcome']);
    } else {
      this.router.navigate(['/error']);
    }
  }


}
